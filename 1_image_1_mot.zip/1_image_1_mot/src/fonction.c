#include "fonction.h"

/*Fonction de Hashage*/
uint32_t hash(char* mot){
    uint32_t hash_value = 0;
    for (size_t i = 0; i < strlen(mot); i++) {
    hash_value = hash_value + (i+1) * mot[i];
    }

    return (hash_value % CAPACITE);
}


void ajouterMot(Hash_table* table, char* francais, char* anglais, char* image){
    //Prépare le mot à l'insertion
    Mot* pointeur_mot = (Mot*) malloc(sizeof(Mot));

    strcpy(pointeur_mot->francais, francais);

    strcpy(pointeur_mot->anglais, anglais);

    strcpy(pointeur_mot->image, image);

    //Calcul le hash du mot et on l'ajoute au tableau
    uint32_t hash_value = hash(pointeur_mot->francais);

    //Vérif collision
    while (table->tableauMot[hash_value] != NULL)
    {
        hash_value++;

        if (hash_value >= CAPACITE)
        {
            hash_value = hash_value /2;
        }
        
    }
    

    table->tableauMot[hash_value] = pointeur_mot;

    //Alloue/Réalloue la taille nécessaire pour notre tableau d'indice
    table->nombreMot++;
    if (table->tableauIndice == NULL)
    {
        //On alloue la mémoire une 1ere fois
        table->tableauIndice = (uint32_t*) malloc(sizeof(uint32_t) * table->nombreMot);
    }
    else{
        //Si il y a deja un élément alors on augmente la taille
        table->tableauIndice = (uint32_t*) realloc(table->tableauIndice ,sizeof(uint32_t) * table->nombreMot);
    }
    table->tableauIndice[table->nombreMot -1] = hash_value;
    
}

void lirefichier(Hash_table* table, const char* chemin)
{
    //Ouvrir le fichier
    FILE* fichier = fopen(chemin, "r");

    if (fichier == NULL)
    {
        printf("Impossible d'ouvrir le fichier ! \n");
        exit(EXIT_FAILURE);
    }
    
    char francais[255];
    char anglais[255];
    char image[255];

    // lire le fichier et stock les mots dans des tableaux de caractères
    while (!feof(fichier))
    {
        fscanf(fichier, "%s %s %s\n", francais, anglais, image);
        ajouterMot(table, francais, anglais, image);
        
    }
    
    fclose(fichier);

}