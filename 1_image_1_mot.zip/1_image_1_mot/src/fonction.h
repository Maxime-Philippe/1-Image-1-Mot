#ifndef __FONCTION_H__
#define __FONCTION_H__
#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


//Facultatif
#include <stdint.h> //pour les unsigned long (uint32_t)

/*Capacité max du tableauMot*/
#define CAPACITE 16384

typedef struct Mot {
    char francais[256];
    char anglais[256];
    char image[256];
}Mot;

/*Définition de la structure table de hashage*/
typedef struct Hash_table {
    Mot* tableauMot[CAPACITE]; //tab de Mot
    unsigned int nombreMot; //nb de mot stocké
    uint32_t* tableauIndice; // tab d'indice (ce qui nous permet de stocker le nb d'indice pour réallouer le tab)
}Hash_table;

/*Prototypes des fonctions qu'on utilise*/
uint32_t hash(char* mot);
void ajouterMot(Hash_table* table, char* francais, char* anglais, char* image);
void lirefichier(Hash_table* table, const char* chemin);

#endif