#ifndef __JEU_H__
#define __JEU_H__
#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "fonction.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

/*Définition de la taille de la Fenetre*/
#define WINDOW_WIDTH 1280 //Largeur fenetre
#define WINDOW_HEIGHT 720 //Hauteur fenetre

/*Structure Game*/
typedef struct game{
	SDL_Window *window;
	SDL_Renderer *renderer;
	SDL_bool running;
	int modeJeux; // 1 si mode solo | 2 si mode duo
	int langue;	// 1 si français | 2 si anglais
	Hash_table table;
}Game;

/*Prototypes des diffèrentes fonctions utilisées*/
void DestroyVariable(SDL_Renderer *renderer, SDL_Window *window);
int ExitError(const char *message);
void initGame(Game *game);
void ChoixMode(Game *game);
void solo(Game *game,Mot* pointeur_mot);
void duo(Game *game);
void afficherTexte(Game *game, char texte[100]);
void updateTexte(char texte[100], char nouveauCaractere[2]);
void affichageMotInvalide(Game *game);

#endif