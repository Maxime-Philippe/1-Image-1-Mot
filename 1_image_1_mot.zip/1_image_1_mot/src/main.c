#include "jeux.h"
#include "fonction.h"

int main(){

	Game game; 

	/*Initialisation du jeux et choix du mode*/
	initGame(&game);
	ChoixMode(&game);

	/*Lancement du mode de jeu séléctionner*/
	if (game.modeJeux == 1)
		solo(&game,NULL);
	
	if (game.modeJeux == 2)
		duo(&game);
	

	/*Destruction des éléments pour éviter les fuites mémoire*/
	DestroyVariable(game.renderer, game.window);
	
	/*Quitter le TTF et la SDL*/
	TTF_Quit();
	SDL_Quit();
}