#include "jeux.h"
#include "fonction.h"


void DestroyVariable(SDL_Renderer *renderer, SDL_Window *window)
{
    SDL_DestroyRenderer(renderer); //Détruit le rendu
    SDL_DestroyWindow(window); //Détruit la fenetre
}

int ExitError(const char *message){
    SDL_Log("erreur %s, %s", message, SDL_GetError());
    SDL_Quit();
    exit(EXIT_FAILURE);
}

void initGame(Game* game){

	/*Lancement Affichage...*/
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
	{
		ExitError("Probème Initialisattion Affichage !");
	}
	    
	/*Creation fenetre*/
	game->window = SDL_CreateWindow("Une Image Un Mot !",SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH,WINDOW_HEIGHT,0);	
	if (game->window == NULL)
	{
		ExitError("Probème Creation Window !");
	}
	
	/*Creation rendu*/
	game->renderer = SDL_CreateRenderer(game->window, -1, SDL_RENDERER_SOFTWARE);
	if (game->renderer == NULL)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Creation Renderer!");
	}

	/*Complète le reste des valeurs de la structure Game*/
	game->running = SDL_TRUE;
	game->modeJeux = 0;
	game->langue = 0;

	game->table.nombreMot = 0;
	game->table.tableauIndice = NULL;
	

	for (int i = 0; i < CAPACITE; i++)
	{
		game->table.tableauMot[i] = NULL;
	}

	/*Initialiser la seed pour l'aléatoire*/
	srand(time(NULL));

	lirefichier(&(game->table),"assets/Theme/Mot.txt");

	TTF_Init();

}

void ChoixMode(Game *game)
{


    /*Création texture d'acceuil*/
	SDL_Texture *texture_acceuil = NULL;
	texture_acceuil = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/acceuil.png");
	if (texture_acceuil == NULL)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Creation de la texture acceuil!");
	}
	
	/*chargement des textures en mémoire*/
	if(SDL_QueryTexture(texture_acceuil, NULL, NULL,NULL, NULL) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Chargement de la texture acceuil!");
	}

	/*Affichage des textures*/
	if(SDL_RenderCopy(game->renderer, texture_acceuil, NULL, NULL) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème affichage de la texture acceuil!");
	}

	/*Actualise le rendu*/
	SDL_RenderPresent(game->renderer);
	

	/*Séléction mode de jeu*/
	SDL_Event mode;
	
	while (game->modeJeux != 1 && game->modeJeux != 2 && game->running)
	{
		while (SDL_PollEvent(&mode))
		{
			switch (mode.type)
			{
			case SDL_QUIT:
                game->running = SDL_FALSE;
                break;
			
			case SDL_KEYUP:
				switch (mode.key.keysym.sym)
				{
				case SDLK_1:
					game->modeJeux = 1;
					break;
					
				case SDLK_2:
					game->modeJeux = 2;
					break;
				}
			}
		}
	}

	

	/*Création texture langue*/
	SDL_Texture *texture_langue = NULL;
	texture_langue = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/langue.png");
	if (texture_langue == NULL)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Creation de la texture langue!");
	}
	
	/*chargement des textures en mémoire*/
	if(SDL_QueryTexture(texture_langue, NULL, NULL,NULL, NULL) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Chargement de la texture langue!");
	}

	/*Affichage des textures*/
	if(SDL_RenderCopy(game->renderer, texture_langue, NULL, NULL) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème affichage de la texture langue!");
	}

	/*Actualise le rendu*/
	SDL_RenderPresent(game->renderer);


	/*Séléction langue de jeu*/
	SDL_Event langue;
	
	while (game->langue != 1 && game->langue != 2 && game->running)
	{
		while (SDL_PollEvent(&langue))
		{
			switch (langue.type)
			{
			case SDL_QUIT:
                game->running = SDL_FALSE;
                break;

			case SDL_KEYUP:
				switch (langue.key.keysym.sym)
				{
				case SDLK_1:
					game->langue = 1;
					break;
					
				case SDLK_2:
					game->langue = 2;
					break;
				
				default:
					continue;
				}
			default:
				break;		
			}
		}
	}


	/*Destruction des textures pour eviter les fuites mémoires*/
	SDL_DestroyTexture(texture_acceuil);
	SDL_DestroyTexture(texture_langue);
}	

void afficherTexte(Game *game, char* texte)
{
	/*Initialisation de SDL_TTF*/
	SDL_Surface *surface_texte = NULL;
	SDL_Texture *texture_texte = NULL;
	TTF_Font *police = NULL;
	SDL_Color couleurNoire={0,0,0,255};

	SDL_Rect cadre_texte;
	cadre_texte.x = 420;
	cadre_texte.y = 660;
	cadre_texte.w = 20 * strlen(texte);
	cadre_texte.h = 20;

	/*Empecher le dépacement de la zone de texte*/
	if (cadre_texte.w > 20 * 23)
	{
		cadre_texte.w = 20 * 23;
	}
	

	police = TTF_OpenFont("assets/TTF/arcade_n .ttf", 25);

	surface_texte = TTF_RenderText_Solid(police,texte,couleurNoire);
	texture_texte = SDL_CreateTextureFromSurface(game->renderer, surface_texte);
	SDL_FreeSurface(surface_texte);

	SDL_RenderCopy(game->renderer, texture_texte, NULL, &cadre_texte);

	SDL_DestroyTexture(texture_texte);
	TTF_CloseFont(police);
		
}

void updateTexte(char* texte, char nouveauCaractere[2])
{
	if ((nouveauCaractere[1]>= 'a' && nouveauCaractere[1]<= 'z') || nouveauCaractere[1] == '_')
	{
		if (strlen(texte)<99)
			strcat(texte,nouveauCaractere);
	}
	else
	{
		switch (nouveauCaractere[1])
		{
		case 8: //caractere du \b (back space)
			if (strlen(texte) >= 1)
				texte[strlen(texte)-1] = '\0';
			break;
		}
	}
	
}

void affichageMotInvalide(Game *game)
{
	/*Initialisation de SDL_TTF*/
	SDL_Surface *surface_texte = NULL;
	SDL_Texture *texture_texte = NULL;
	TTF_Font *police = NULL;
	SDL_Color couleurNoire={255,0,0,255};

	SDL_Rect cadre_texte;
	cadre_texte.x = 450;
	cadre_texte.y = 700;
	cadre_texte.w = 400;
	cadre_texte.h = 20;



	police = TTF_OpenFont("assets/TTF/arcade_n .ttf", 25);

	surface_texte = TTF_RenderText_Solid(police,"Saississez un mot valide !",couleurNoire);
	texture_texte = SDL_CreateTextureFromSurface(game->renderer, surface_texte);
	SDL_FreeSurface(surface_texte);

	SDL_RenderCopy(game->renderer, texture_texte, NULL, &cadre_texte);
	SDL_RenderPresent(game->renderer);

	SDL_Delay(2000);

	SDL_DestroyTexture(texture_texte);
	TTF_CloseFont(police);
	
}

void solo(Game *game,Mot* pointeur_mot){

	/*Création texture de fond de base*/
	SDL_Texture *texture_base = NULL;
	texture_base = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/base.png");
	if (texture_base == NULL)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Creation de la texture de fond de base!");
	}
	
	/*chargement des textures en mémoire*/
	if(SDL_QueryTexture(texture_base, NULL, NULL,NULL, NULL) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Chargement de la texture de fond de base!");
	}

	/*Création du cadre où on va afficher les images*/
	SDL_Rect rectangle_image;

	rectangle_image.x = (WINDOW_WIDTH/2) -( 510/2)+25;
	rectangle_image.y = (WINDOW_HEIGHT/2) -( 340/2)-150;
	rectangle_image.w = 0; 
	rectangle_image.h = 0;

	SDL_Texture *texture_image = NULL;
	int valeur_aleatoire;
	char* image_aleatoire;
	if(pointeur_mot == NULL)
	{
		valeur_aleatoire = rand() % game->table.nombreMot;
		image_aleatoire = game->table.tableauMot[game->table.tableauIndice[valeur_aleatoire]]->image;
		texture_image = IMG_LoadTexture(game->renderer,image_aleatoire);
	}
	else
	{
		texture_image = IMG_LoadTexture(game->renderer, pointeur_mot->image);
	}

	/*Création texture image francais*/
	if (texture_image == NULL)
	{
		DestroyVariable(game->renderer, game->window); 
		ExitError("Probème Creation de la texture image francais!");
	}
	
	/*chargement des textures en mémoire*/
	if(SDL_QueryTexture(texture_image, NULL, NULL, &rectangle_image.w, &rectangle_image.h) != 0)
	{
		DestroyVariable(game->renderer, game->window);
		ExitError("Probème Chargement de la texture image francais!");
	}


	char* texte = (char*) malloc(sizeof(char) * 100);
	texte[0] = '\0';
	char concat[2];

	SDL_Event event;
	int flagModif = 0;
	int flagVictoire = 0;

	while (game->running && flagVictoire == 0)
	{
		SDL_RenderClear(game->renderer);

		//-ENTRER
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_QUIT:
                game->running = SDL_FALSE;
                break;

			case SDL_KEYUP:
				flagModif = 1;
				switch (event.key.keysym.sym)
				{
				case SDLK_a:
					strcat(texte, "a"); 
					break;
				
				case SDLK_b:
					strcat(texte,"b" ); 
					break;

				case SDLK_c:
					strcat(texte, "c");
					break;

				case SDLK_d:
					strcat(texte, "d"); 
					break;

				case SDLK_e:
					strcat(texte, "e"); 
					break;

				case SDLK_f:
					strcat(texte, "f"); 
					break;

				case SDLK_g:
					strcat(texte, "g"); 
					break;

				case SDLK_h:
					strcat(texte, "h"); 
					break;

				case SDLK_i:
					strcat(texte,"i" ); 
					break;

				case SDLK_j:
					strcat(texte, "j"); 
					break;

				case SDLK_k:
					strcat(texte, "k"); 
					break;

				case SDLK_l:
					strcat(texte, "l"); 
					break;

				case SDLK_m:
					strcat(texte, "m"); 
					break;

				case SDLK_n:
					strcat(texte, "n"); 
					break;

				case SDLK_o:
					strcat(texte, "o"); 
					break;

				case SDLK_p:
					strcat(texte, "p"); 
					break;

				case SDLK_q:
					strcat(texte, "q"); 
					break;

				case SDLK_r:
					strcat(texte,"r"); 
					break;

				case SDLK_s:
					strcat(texte, "s"); 
					break;
				
				case SDLK_t:
					strcat(texte, "t"); 
					break;

				case SDLK_u:
					strcat(texte, "u"); 
					break;

				case SDLK_v:
					strcat(texte, "v"); 
					break;

				case SDLK_w:
					strcat(texte, "w"); 
					break;

				case SDLK_x:
					strcat(texte, "x"); 
					break;

				case SDLK_y:
					strcat(texte, "y"); 
					break;

				case SDLK_z:
					strcat(texte, "z"); 
					break;

				case SDLK_BACKSPACE:
					strcat(concat, "\b"); 
					break;

				case SDLK_SPACE:
					strcat(texte, "_"); 
					break;
				
				case SDLK_RETURN:
					if (game->langue == 1)
					{
						if(pointeur_mot != NULL)
						{
							if(strcmp(texte,pointeur_mot->francais) == 0)
							{
								flagVictoire = 1;
							}
							else
							{
								flagVictoire = 2;
							}
						}
						else
						{
							if(strcmp(texte,game->table.tableauMot[game->table.tableauIndice[valeur_aleatoire]]->francais) == 0)
							{
								flagVictoire = 1;
							}
							else
							{
								flagVictoire = 2;
							}	
						}
						
						break;
					}
					else
					{
						if(pointeur_mot != NULL)
						{
							if(strcmp(texte,pointeur_mot->anglais) == 0)
							{
								flagVictoire = 1;
							}
							else
							{
								flagVictoire = 2;
							}
						}
						else
						{
							if(strcmp(texte,game->table.tableauMot[game->table.tableauIndice[valeur_aleatoire]]->anglais) == 0)
							{
								flagVictoire = 1;
							}
							else
							{
								flagVictoire = 2;
							}	
						}
						break;
					}
				}
					
			}
		}
		


			
		//-MISE A JOUR 
		if (flagModif == 1)
		{
			updateTexte(texte, concat);
			concat[1] = '\0';
		}
			

		//-AFFICHAGE
		if(SDL_RenderCopy(game->renderer, texture_base, NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème affichage de la texture de fond de base!");
		}

		/*Affichage des textures*/
		if(SDL_RenderCopy(game->renderer, texture_image, NULL, &rectangle_image) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème affichage de la texture image francais!");
		}

		afficherTexte(game, texte);

		SDL_RenderPresent(game->renderer);

		flagModif = 0;

		SDL_Delay(20);
	}

	if(flagVictoire == 1)
	{	
		SDL_Texture *texture_victoire = NULL;
		texture_victoire = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/gagner.png");
		if (texture_victoire == NULL)
		{
			DestroyVariable(game->renderer, game->window); 
			ExitError("Probème Creation de la texture victoire !");
		}

		SDL_RenderClear(game->renderer);

		/*chargement des textures en mémoire*/
		if(SDL_QueryTexture(texture_victoire, NULL, NULL,NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème Chargement de la texture victoire!");
		}

		/*Affichage des textures*/
		if(SDL_RenderCopy(game->renderer, texture_victoire, NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème affichage de la texture victoire!");
		}

		/*Actualise le rendu*/
		SDL_RenderPresent(game->renderer);


		while (game->running)
		{
			SDL_Event quitter;
			while (SDL_PollEvent(&quitter))
			{
				switch (quitter.type)
				{
				case SDL_QUIT:
					game->running = SDL_FALSE;
					break;
				}
			}
		}
		
	}
	else if (flagVictoire == 2)
	{
		SDL_Texture *texture_defaite = NULL;
		texture_defaite = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/perdu.png");
		if (texture_defaite == NULL)
		{
			DestroyVariable(game->renderer, game->window); 
			ExitError("Probème Creation de la texture defaite !");
		}

		SDL_RenderClear(game->renderer);

		/*chargement des textures en mémoire*/
		if(SDL_QueryTexture(texture_defaite, NULL, NULL,NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème Chargement de la texture defaite!");
		}

		/*Affichage des textures*/
		if(SDL_RenderCopy(game->renderer, texture_defaite, NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème affichage de la texture defaite!");
		}

		/*Actualise le rendu*/
		SDL_RenderPresent(game->renderer);

		while (game->running)
		{
			SDL_Event quitter;
			while (SDL_PollEvent(&quitter))
			{
				switch (quitter.type)
				{
				case SDL_QUIT:
					game->running = SDL_FALSE;
					break;
				}
			}
		}
	}
	

	/*Destruction de la texture pour eviter les fuites mémoires*/
	SDL_DestroyTexture(texture_image);
	SDL_DestroyTexture(texture_base);

}

void duo(Game *game)
{
	
	char* motJ1 = (char*) malloc(sizeof(char) * 100);
	motJ1[0] = '\0';
	char concat[2];

	int hash_value_motJ1 = 0;
	int flagModif = 0;
	
	SDL_Texture *texture_motJ1 = NULL;
	SDL_Event event_motJ1;
	while (game->running)
	{
		SDL_RenderClear(game->renderer);
		/*Création texture motJ1*/
		texture_motJ1 = IMG_LoadTexture(game->renderer,"assets/Image_Jeu/motJ1.png");
		if (texture_motJ1 == NULL)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème Creation de la texture motJ1!");
		}

		/*chargement des textures en mémoire*/
		if(SDL_QueryTexture(texture_motJ1, NULL, NULL,NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème Chargement de la texture motJ1!");
		}

		if(SDL_RenderCopy(game->renderer, texture_motJ1, NULL, NULL) != 0)
		{
			DestroyVariable(game->renderer, game->window);
			ExitError("Probème affichage de la texture motJ1!");
		}

		SDL_RenderPresent(game->renderer);
		SDL_DestroyTexture(texture_motJ1);

		//-ENTRER
		while (SDL_PollEvent(&event_motJ1))
		{
			switch (event_motJ1.type)
			{
			case SDL_QUIT:
				game->running = SDL_FALSE;
				break;

			case SDL_KEYUP:
			flagModif = 1;
				switch (event_motJ1.key.keysym.sym)
				{
				case SDLK_a:
					strcat(motJ1, "a"); 
					break;
				
				case SDLK_b:
					strcat(motJ1,"b" ); 
					break;

				case SDLK_c:
					strcat(motJ1, "c");
					break;

				case SDLK_d:
					strcat(motJ1, "d"); 
					break;

				case SDLK_e:
					strcat(motJ1, "e"); 
					break;

				case SDLK_f:
					strcat(motJ1, "f"); 
					break;

				case SDLK_g:
					strcat(motJ1, "g"); 
					break;

				case SDLK_h:
					strcat(motJ1, "h"); 
					break;

				case SDLK_i:
					strcat(motJ1,"i" ); 
					break;

				case SDLK_j:
					strcat(motJ1, "j"); 
					break;

				case SDLK_k:
					strcat(motJ1, "k"); 
					break;

				case SDLK_l:
					strcat(motJ1, "l"); 
					break;

				case SDLK_m:
					strcat(motJ1, "m"); 
					break;

				case SDLK_n:
					strcat(motJ1, "n"); 
					break;

				case SDLK_o:
					strcat(motJ1, "o"); 
					break;

				case SDLK_p:
					strcat(motJ1, "p"); 
					break;

				case SDLK_q:
					strcat(motJ1, "q"); 
					break;

				case SDLK_r:
					strcat(motJ1,"r"); 
					break;

				case SDLK_s:
					strcat(motJ1, "s"); 
					break;
				
				case SDLK_t:
					strcat(motJ1, "t"); 
					break;

				case SDLK_u:
					strcat(motJ1, "u"); 
					break;

				case SDLK_v:
					strcat(motJ1, "v"); 
					break;

				case SDLK_w:
					strcat(motJ1, "w"); 
					break;

				case SDLK_x:
					strcat(motJ1, "x"); 
					break;

				case SDLK_y:
					strcat(motJ1, "y"); 
					break;

				case SDLK_z:
					strcat(motJ1, "z"); 
					break;

				case SDLK_BACKSPACE:
					strcat(concat, "\b"); 
					break;

				case SDLK_SPACE:
					strcat(motJ1, "_"); 
					break;

				
				case SDLK_RETURN:
					hash_value_motJ1 = hash(motJ1);
					int flagTrouver = 0;
					if(game->table.tableauMot[hash_value_motJ1] != NULL)
					{
						for (size_t i = 0; i < 5; i++)
						{
							if(game->table.tableauMot[hash_value_motJ1] != NULL && strcmp(motJ1, game->table.tableauMot[hash_value_motJ1]->francais) == 0)
							{
								flagTrouver = 1;
								break;
							}

							hash_value_motJ1++;
						}
						
						if (flagTrouver == 1)
						{
							solo(game, game->table.tableauMot[hash_value_motJ1]);
						}
						else
						{
							affichageMotInvalide(game);
							motJ1[0] = '\0';
						}

					}
					else
					{
						affichageMotInvalide(game);
						motJ1[0] = '\0';
					}

					break;
				}
					
			}
		}
		
		if (flagModif == 1)
		{
			updateTexte(motJ1, concat);
			concat[1]= '\0';
		}
		
		afficherTexte(game, motJ1);

		SDL_RenderPresent(game->renderer);

		SDL_Delay(30);
	}
}
